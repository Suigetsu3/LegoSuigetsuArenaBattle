
# Lego Suigetsu — Arena Battle (Mobile-ready package)

Paket ini berisi model placeholder (OBJ), skrip gameplay dasar, dan workflow GitHub Actions untuk **mencoba** membangun APK secara otomatis menggunakan GitHub Actions + game-ci/unity-builder.

**Important limitations (read first)**
- Saya tidak dapat langsung membuat APK di lingkungan ini. Namun paket ini menyediakan semua aset & skrip yang diperlukan untuk membangun APK di cloud (GitHub Actions) atau di PC.
- Untuk membangun lewat GitHub Actions, kamu perlu:
  1. Akun GitHub dan repo baru.
  2. Unity Editor version (mis. 2021.3.x) yang digunakan oleh workflow.
  3. UNITY_LICENSE (Unity personal/Pro license) atau menggunakan Unity Hub activation flow — game-ci docs menjelaskan langkah aktivasi.
  4. Mengatur Secrets di repo: `UNITY_LICENSE`, `ANDROID_KEYSTORE_BASE64` (jika ingin sign), dll.

## Cara cepat (tanpa PC) — pilihan realistis
1. **Gunakan GitHub + Actions (direkomendasikan jika tidak punya PC):**
   - Buat repo baru di GitHub.
   - Upload seluruh isi folder `Assets/` dan file workflow (`.github/workflows/unity-build.yml`).
   - Atur Secrets untuk `UNITY_LICENSE` (lihat game-ci docs), `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASS`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_ALIAS_PASS`.
   - Push, dan GitHub Actions akan menjalankan builder untuk menghasilkan APK di artefak Actions yang bisa kamu download lewat ponsel.

2. **Gunakan Unity Cloud Build (memerlukan akun Unity dan mungkin langganan Teams):**
   - Buat project di Unity Dashboard, hubungkan repo, pilih platform Android.
   - Start build, download APK hasilnya.

3. **Sewa PC virtual singkat (mis. Paperspace, Google Cloud) atau minta bantuan teman:** build langsung di Unity Editor dan upload APK ke Google Drive / Telegram.

## Struktur paket
- `Assets/Models/` — suigetsu.obj, arena.obj (import di Unity sebagai model).  
- `Assets/Scripts/` — PlayerAttack.cs, EnemyDummy.cs, Health.cs, UIManager.cs.  
- `.github/workflows/unity-build.yml` — contoh workflow untuk GitHub Actions (game-ci/unity-builder).

## Langkah setelah build
1. Pasang APK di HP (sumber tidak dipercaya -> aktifkan instal dari sumber tidak dikenal).  
2. Jalankan game: kontrol default (joystick keyboard jika emulator), tombol serang = tap virtual / space.

## Saya bisa bantu lebih jauh
- Saya bisa isi repo GitHub untukmu (membuat ZIP siap upload) — sudah termasuk di paket ini.  
- Jika kamu mau, aku juga bisa bantu langkah demi langkah memasang Secrets GitHub dari HP-mu.

