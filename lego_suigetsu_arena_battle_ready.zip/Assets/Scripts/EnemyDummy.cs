
using UnityEngine;

public class EnemyDummy : MonoBehaviour
{
    public int maxHealth = 100;
    int currentHealth;

    void Start()
    {
        currentHealth = maxHealth;
    }

    public void TakeDamage(int amount)
    {
        currentHealth -= amount;
        if(currentHealth <= 0) Die();
    }

    void Die()
    {
        // Simple destroy or respawn
        Destroy(gameObject, 0.2f);
    }
}
