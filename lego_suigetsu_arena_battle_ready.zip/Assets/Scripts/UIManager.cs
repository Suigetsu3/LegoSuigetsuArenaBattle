
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public Text enemyCountText;

    public void SetEnemyCount(int count)
    {
        if(enemyCountText != null) enemyCountText.text = "Enemies: " + count;
    }
}
