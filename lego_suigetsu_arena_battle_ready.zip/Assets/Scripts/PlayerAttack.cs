
using UnityEngine;

[RequireComponent(typeof(Animator))]
public class PlayerAttack : MonoBehaviour
{
    public float attackRange = 1.2f;
    public int attackDamage = 25;
    public float attackCooldown = 0.6f;
    float lastAttack = -10f;
    Animator animator;

    void Start()
    {
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        if(Time.time - lastAttack >= attackCooldown)
        {
            if(Input.GetButtonDown("Fire1") || Input.GetKeyDown(KeyCode.Space))
            {
                Attack();
            }
        }
    }

    void Attack()
    {
        lastAttack = Time.time;
        if(animator != null) animator.SetTrigger("Attack");

        RaycastHit hit;
        if(Physics.Raycast(transform.position + Vector3.up*0.8f, transform.forward, out hit, attackRange))
        {
            var h = hit.collider.GetComponent<Health>();
            if(h != null) h.TakeDamage(attackDamage);
        }
    }
}
